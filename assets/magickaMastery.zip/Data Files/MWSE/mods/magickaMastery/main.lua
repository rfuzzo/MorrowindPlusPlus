--[[
    Magicka Mastery
    Author: MageKing17

    Lua port by Greatness7 & NullCascade
--]]

local function getCostReduction(skill, cost)
    local reduction

    if skill < 100 then
        reduction = math.max(0, cost * (skill-50) / 100)
    elseif skill < 200 then
        reduction = cost * ((skill-100) / 400 + 0.50)
    else
        reduction = cost * (math.max(skill-200, 100) / 800 + 0.75)
    end

    return math.min(reduction, cost - 1)
end


local function onSpellCasted(e)
    if e.source.castType ~= tes3.spellType.spell then
        -- ignore powers/abilities
        return
    end

    if e.caster.object.objectType ~= tes3.objectType.npc then
        -- ignore creature casters
        return
    end

    local cost = e.source.magickaCost
    if cost <= 0 then
        -- ignore zero cost spells
        return
    end

    local mobile = e.caster.mobile
    local school = tes3.magicSchoolSkill[e.expGainSchool]
    local skill = mobile.skills[school+1]

    -- replenish magicka
    if skill.current > 50 then
        local reduction = getCostReduction(skill.current, cost)
        local newMagicka = mobile.magicka.current + reduction
        tes3.setStatistic{reference=e.caster, name="magicka", current=newMagicka}
    end

    -- exercise skill
    if mobile == tes3.mobilePlayer then
        -- prevent vanilla exercise mechanic
        e.expGainSchool = tes3.magicSchool.none

        if e.eventType == "spellCasted" then
            mobile:exerciseSkill(school, cost / 10)
        else -- spellCastedFailure
            mobile:exerciseSkill(school, cost / 100)
        end
    end
end
event.register("spellCasted", onSpellCasted)
event.register("spellCastedFailure", onSpellCasted)
