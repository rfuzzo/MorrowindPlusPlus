This is a modified version of MUSE 2.0.2 Necro Edit by Necrolesian. I've
redacted the document to reflect the changes made by this package.

In addition to Necro's tweaks, I've restored the vanilla music that plays at
the Imperial Prison Ship during the beginning of the game.

- Sigourn

This is a modified version of (some of) the MUSE lua files that fixes a few
bugs and/or makes a few changes to MUSE functionality.

This archive contains only the modified lua files. The MUSE lua files that are
not modified are not included, so you'll need to install this on top of MUSE.

This package fixes a few bugs in MUSE so it works the way the author intended. 
These bugs are: (1) an error in the combat threshold formula that caused the 
threshold to drop off at level 30, and (2) added a nil check to the tileset 
statics code to prevent spamming MWSE.log with errors.

This package additionally makes a few changes to functionality: (1) underwater 
and air music is disabled entirely to improve performance by removing unneeded 
checks every frame, and (2) another unneeded every-frame check related to game 
time is also disabled, for performance.

- Necro