local mod = {
    name = "KT1 Magicka Mechanics",
    ver = "1.0",
    cf = {onOff = true, key = {keyCode = tes3.scanCode.l, isShiftDown = false, isAltDown = false, isControlDown = false}, dropDown = 0, slider = 10, sliderpercent = 50, blocked = {}, npcs = {}, textfield = "hello", switch = false}
            }
local cf = mwse.loadConfig(mod.name, mod.cf)



---@param e spellMagickaUseEventData
function mod.onMagickaUse(e)
    if not cf.onOff then
        return
    end
    if e.caster ~= tes3.player then
        return
    end
    local school = e.spell:getLeastProficientSchool(tes3.player)
    local skill = tes3.magicSchoolSkill[school]
    local level = tes3.mobilePlayer:getSkillValue(skill)
    e.cost = math.max(1, e.cost*(100+(cf.sliderpercent)-level)/100)
end

---@param e spellCastedEventData
function mod.onSpellCasted(e)
    if not cf.onOff then
        return
    end
    if e.caster ~= tes3.player then
        return
    end
    local skill = tes3.magicSchoolSkill[e.expGainSchool]
    local level = tes3.mobilePlayer:getSkillValue(skill)
    local cost = math.max(1, e.source.magickaCost*(100+(cf.sliderpercent)-level)/100)
    tes3.mobilePlayer:exerciseSkill(skill, math.max(1, cost/(cf.slider)))
end


function mod.updatingTheSpellMenu()
    local menu = tes3ui.findMenu("MenuMagic")
    if not menu or not menu.visible then
        return
    end
    local spellList = {}
    local spells = {}
    local cost = {}
    local ListSpells = {}
    local ListChance = {}
    for i,spell in pairs(tes3.mobilePlayer.object.spells) do
        table.insert(spellList, i, spell.name)
        table.insert(cost, i, spell.magickaCost)
        local school = spell:getLeastProficientSchool(tes3.player)
        local skill = tes3.magicSchoolSkill[school]
        table.insert(spells, i, tes3.mobilePlayer:getSkillValue(skill))
    end

    local SpellName = menu:findChild("MagicMenu_spell_names")
        for i, child in ipairs(SpellName.children) do
            if table.find(spellList, child.text) then
                table.insert(ListSpells, i, spells[table.find(spellList, child.text)])
                table.insert(ListChance, i, cost[table.find(spellList, child.text)])
            end
        end
    local menuCost = menu:findChild("MagicMenu_spell_costs")
        for i, child in ipairs(menuCost.children) do
            if cf.onOff then
        child.text = string.format("%d", math.max(1, ListChance[i]*(100+(cf.sliderpercent)-ListSpells[i])/100))
            else
        child.text = string.format("%d",ListChance[i])
            end
    end
end


function mod.registerModConfig()
    local template = mwse.mcm.createTemplate(mod.name)
    template:saveOnClose(mod.name, cf)
    template:register()

    local page = template:createSideBarPage({label="\""..mod.name.."\" Settings"})
    page.sidebar:createInfo{ text = "Welcome to \""..mod.name.."\" Configuration Menu. \n \n \n A mod by Spammer."}
    page.sidebar:createHyperLink{ text = "Spammer's Nexus Profile", url = "https://www.nexusmods.com/users/140139148?tab=user+files" }

    local category0 = page:createCategory("Mod active?")
    category0:createOnOffButton{label = "On/Off", description = "Turns the mod Off or On.", variable = mwse.mcm.createTableVariable{id = "onOff", table = cf}}

    local category2 = page:createCategory("Config:")
    local subcat = category2:createCategory("")

    subcat:createSlider{label = "Exp Boost Treshold", description = "Min magicka cost of a spell to grant you an exp bonus. [Default: 10]", min = 0, max = 100, step = 1, jump = 1, variable = mwse.mcm.createTableVariable{id = "slider", table = cf}}

    subcat:createSlider{label = "Magicka Cost Treshold", description = "\"Base\" skill level, at which the Spell magicka cost will be equal to vanilla. Skill level lower than that will make spells cost more magicka. Skill level higher than that will make spells cost less magicka. [Default: 50]", min = 0, max = 100, step = 1, jump = 10, variable = mwse.mcm.createTableVariable{id = "sliderpercent", table = cf}}
end


return mod